SHAH JEWELLERY WEBSITE

1. Upload index.html to your GitHub repository.
2. Before sharing the website, edit index.html and find:
   const WHATSAPP_NUMBER = "91XXXXXXXXXX";
   Replace it with your WhatsApp number including India country code 91, without + or spaces.
3. Replace the sample product names, prices, descriptions and image URLs in the products list with your real products.
4. In GitHub, open repository Settings > Pages. Choose Deploy from a branch, select main and / (root), then Save.
5. Your website link will appear in Settings > Pages after publishing finishes.

This is a static website. Orders open WhatsApp with the cart and customer details pre-filled; no online payment gateway is connected yet.
